# Agent UI Lab：人工審核詢價郵件

本 Lab 使用獨立的 uv 專案。你將啟動本機 Agent Server，從 Agent Chat UI 補齊詢價資料、拒絕郵件草稿，再修改郵件參數並觀察執行結果。課內操作時間為 15 分鐘，環境安裝須在課前完成。

## 學習目標

- 將 Graph ID 對應至 Python 檔案中的 Agent 物件。
- 從 Agent Chat UI 連線本機 Agent Server。
- 使用 `respond`、`reject` 與 `edit` 決策。
- 以工具輸出判斷模擬寄信是否執行。

## 專案檔案

| 檔案 | 用途 |
|---|---|
| `inquiry_helper.py` | 完整 Agent、資料驗證工具及 HITL policy |
| `langgraph.json` | 學生填寫的 Agent 載入設定 |
| `.env.example` | 環境變數範本 |
| `pyproject.toml` | uv 專案設定與相依套件範圍 |
| [inputs.md](inputs.md) | 可複製的測試訊息 |
| [submission.md](submission.md) | 成果紀錄與繳交格式 |

## 課前準備

先安裝 [uv](https://docs.astral.sh/uv/getting-started/installation/)。本 Lab 預設使用 `gpt-5-nano`，請準備可呼叫該模型的 OpenAI API key；若使用 Gemini，依下一節設定 Google API key。本 Lab 的模型呼叫會使用對應供應商的 API 額度。

本 Lab 依官方本機開發流程，統一要求課前準備 LangSmith 帳號與 API key。到 [LangSmith](https://smith.langchain.com/) 註冊或登入，再依 [建立 API key 的官方說明](https://docs.langchain.com/langsmith/create-account-api-key) 取得自己的 key。學生若自行操作 Studio，也使用自己的帳號登入。

將終端機切換到本資料夾，確認目前目錄中有 `pyproject.toml`，再執行：

```bash
uv sync
```

複製 `.env.example` 為 `.env`，將 `OPENAI_API_KEY` 換成自己的 key。macOS／Linux 可使用：

```bash
cp .env.example .env
```

Windows PowerShell 可使用：

```powershell
Copy-Item .env.example .env
```

編輯 `.env`，填入模型供應商的 key，並新增或取消註解 `LANGSMITH_API_KEY`。以預設 OpenAI 模型為例：

```dotenv
OPENAI_API_KEY=replace_with_your_openai_api_key
LANGSMITH_API_KEY=replace_with_your_langsmith_api_key
LANGSMITH_TRACING=false
```

| 設定 | 用途 |
|---|---|
| `OPENAI_API_KEY` 或 `GOOGLE_API_KEY` | 呼叫模型供應商的 API |
| `LANGSMITH_API_KEY` | 存取 LangSmith 服務，依官方本機開發與 Studio 流程準備 |
| `LANGSMITH_TRACING=false` | 關閉將執行追蹤資料上傳至 LangSmith；此設定與帳號登入、API key 分開處理 |

`uv sync` 會解析相依套件並建立 `uv.lock`。若教師已提供鎖定檔，改用 `uv sync --locked` 安裝相同版本。

`.env` 只保留在自己的電腦，不列入繳交內容。課前先確認套件下載完成，並請教師協助排除本機連線問題。

## 更換模型（課前選用）

模型由 `inquiry_helper.py` 最後的 `create_agent()` 建立。更換模型時，需要配合調整供應商套件、API key 與 `model` 參數。本 Lab 使用模型產生 Tool Call，因此選用的模型必須支援 tool calling。

若繼續使用 OpenAI，只需將 `model="gpt-5-nano"` 改為帳號可使用、支援 tool calling 的 OpenAI 模型 ID，並沿用 `OPENAI_API_KEY`。

### 改用 Gemini

以下使用 Gemini Developer API。先在本專案目錄安裝 Google 整合套件：

```bash
uv add langchain-google-genai
```

此指令會更新 `pyproject.toml`、`uv.lock` 與本機環境。接著從 [Google AI Studio](https://aistudio.google.com/apikey) 取得 API key，在 `.env` 加入：

```dotenv
GOOGLE_API_KEY=replace_with_your_google_api_key
```

只使用 Gemini 時，可刪除或註解 `.env` 中的 `OPENAI_API_KEY`。Agent Server 會依 `langgraph.json` 的 `env` 設定載入 `.env`。

接著修改 `inquiry_helper.py` 最後建立 Agent 的區段。`create_agent()` 接受 `供應商:模型 ID` 格式的字串，並自動建立對應的模型物件。`google_genai` 指定 Google Gemini 整合。以下取代原本的 Agent 建立區段，保留前文定義的 prompt、工具與 middleware：

```python
from langchain.agents import create_agent

agent = create_agent(
    model="google_genai:gemini-3.6-flash",
    system_prompt=system_prompt,
    tools=[validate_inquiry_data, ask_user, send_email],
    middleware=[interrupt_policy],
)
```

範例模型 ID 採用 LangChain 官方 Agent 文件的示例；請依 [Gemini 模型文件](https://ai.google.dev/gemini-api/docs/models) 選用帳號可存取、支援 function calling 的模型，並替換冒號後的模型 ID。這種寫法仍需先安裝整合套件並設定 API key。

完成設定後，若 Server 已啟動，先以 `Ctrl+C` 停止，再執行 `uv run langgraph dev`。在 Agent Chat UI 建立新對話，使用相同測試素材確認工具呼叫與人工審核流程。Graph ID 與 UI 連線方式沿用後續步驟。

## 1. 設定 Agent（0–2 分鐘）: 修改 langgraph.json`設定

Agent Server 透過 `langgraph.json` 的 `graphs` 欄位載入 Agent。Key 是 UI 使用的 Graph ID，value 格式為 `<Python 檔案路徑>:<物件名稱>`。

開啟 `inquiry_helper.py`，找到最後建立 Agent 的變數，將被用來做為 `<物件名稱>`。

接著將 `langgraph.json` 中的 `TODO_PYTHON_FILE:TODO_OBJECT_NAME` 換成正確值。

保留 Graph ID `agent`。


## 2. 啟動並連線（2–4 分鐘）

在本專案目錄執行，並保持終端機開啟：

```bash
uv run langgraph dev
```

開啟 [Agent Chat UI](https://agentchat.vercel.app/)，填入：

| 欄位 | 值 |
|---|---|
| Graph ID | `agent` |
| Deployment URL | `http://127.0.0.1:2024` |
| LangSmith API Key | 本機預設連線可留白 |

此處的 API key 欄位用於 UI 連線。官方 Agent Chat UI 文件說明，連線本機 Agent Server 時可留白；課前在 `.env` 準備的 `LANGSMITH_API_KEY` 則依本機開發流程設定。

## 3. 補齊交貨日期（4–7 分鐘）

從 [測試素材](inputs.md#1-初始詢價訊息) 複製初始訊息，送出至新對話。輸入刻意省略 `delivery_date`。

Agent 應先呼叫 `validate_inquiry_data`，再透過 `ask_user` 要求補充日期。在人工回覆欄填入晚於今天的日期，完成 `respond`。Agent 會合併資料並再次驗證。

## 4. 拒絕中文郵件（7–10 分鐘）

出現 `send_email` 審查畫面時，先觀察主旨、內文與收件人。工具此時等待人工決策。

選擇 Reject，填入「需要英文版本，請將郵件主旨與內文改為英文。」並提交。查看對話中的拒絕結果，並確認終端機沒有因這次被拒絕的呼叫而新增 `Sending email to ...` 輸出。

若 Agent 已提出新的英文郵件審查，直接進入下一步；若它停止並等待新訊息，輸入「請依照剛才的要求產生英文詢價郵件，並呼叫寄信工具。」

## 5. 修改主旨並執行（10–12 分鐘）

在新的 `send_email` 審查畫面中，保留其他參數，將 `subject` 開頭加上 `[Lab]`，再送出 Edit 決策。

`edit` 會使用修改後的參數執行工具，無須再送一次 `approve`。本案例的寄信工具只輸出至終端機，並回傳含 `success` 的結果，不連線郵件服務。

查看終端機的 `Subject:` 是否包含 `[Lab]`，並在 UI 查看工具回傳結果。擷取終端機的模擬寄信輸出作為成果證據。

## 6. 觀察 Studio 與繳交（12–15 分鐘）

教師登入 LangSmith 後，示範 Studio 的原始 interrupt 與 `approve` 決策。`approve` 使用原始參數執行工具；`edit` 則使用人工修改後的參數。

完成 [成果紀錄表](submission.md)，繳交一張終端機輸出截圖與兩題簡答。

## 常見問題

| 現象 | 檢查方式 |
|---|---|
| 啟動時找不到檔案或物件 | 確認已替換 `langgraph.json` 中的 TODO，路徑相對於該設定檔 |
| 模型認證或額度錯誤 | 依供應商檢查 `.env` 中的 `OPENAI_API_KEY` 或 `GOOGLE_API_KEY`、模型存取權與 API 額度 |
| UI 找不到 Agent | 確認 Server 仍在執行，Graph ID 為 `agent`，URL 與終端機顯示一致 |
| 2024 port 被占用 | 停止先前的 Server，或依 CLI 說明改 port，並同步更新 UI URL |
| 日期一直驗證失敗 | 使用晚於執行當天的日期，格式為 `YYYY-MM-DD` |
| UI 無法連線 localhost | 先開啟 `http://127.0.0.1:2024/docs` 確認 Server，再由教師依官方文件協助處理瀏覽器權限或 tunnel |

## 參考資料

- [原課程講義](../agent_ui.md)（單獨分發本資料夾時，可由教師另提供）
- [uv 專案結構](https://docs.astral.sh/uv/concepts/projects/layout/)
- [Local development & testing](https://docs.langchain.com/langsmith/local-dev-testing)
- [建立 LangSmith 帳號與 API key](https://docs.langchain.com/langsmith/create-account-api-key)
- [Get started with Studio](https://docs.langchain.com/langsmith/quick-start-studio)
- [Agent Chat UI](https://docs.langchain.com/oss/python/langchain/ui)
- [Human-in-the-Loop](https://docs.langchain.com/oss/python/langchain/human-in-the-loop)
- [Google Gemini 整合](https://docs.langchain.com/oss/python/integrations/chat/google_generative_ai)
- [Agents：模型設定](https://docs.langchain.com/oss/python/langchain/agents#model)
- [Gemini 模型與功能](https://ai.google.dev/gemini-api/docs/models)
- [Studio troubleshooting](https://docs.langchain.com/langsmith/troubleshooting-studio)
