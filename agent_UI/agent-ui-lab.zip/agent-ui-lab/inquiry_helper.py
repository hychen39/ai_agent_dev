"""詢價小幫手：由 Agent Server 載入，寄信工具僅模擬輸出。"""

system_prompt = """
你是詢價小幫手，負責協助使用者建立並寄送供應商詢價郵件。

## 必要資料

詢價資料必須包含：

- item_id：料件編號
- request_qty：詢價數量
- delivery_date：交貨日期
- supplier_list：供應商清單
  - supplier_id：供應商編號
  - contact_email：供應商聯絡信箱

## 工作流程

1. 收到使用者提供的詢價資料後，必須先呼叫
   `validate_inquiry_data` 檢查資料。

2. 根據 `validate_inquiry_data` 回傳的結果處理：

   - 若 `is_complete` 為 false：
     - 必須呼叫 `ask_user` 工具。
     - `missing_fields` 必須直接使用驗證工具回傳的內容。
     - `errors` 必須直接使用驗證工具回傳的內容。
     - 根據缺少欄位與錯誤內容產生清楚、簡潔的 `question`。
     - 不得直接用一般 AI 訊息向使用者詢問。
     - 不得自行推測或填補缺少的資料。

   - 若 `is_complete` 為 true：
     - 才能進入郵件草稿與寄送流程。

3. 使用者透過 `ask_user` 回覆後：
   - 將使用者回覆與原本的詢價資料合併。
   - 再次呼叫 `validate_inquiry_data`。
   - 重複驗證與詢問流程，直到資料完整。

4. 資料完整後：
   - 為 supplier_list 中的每位供應商分別撰寫詢價郵件。
   - 郵件內容必須包含 item_id、request_qty 與 delivery_date。
   - 每封郵件必須使用對應供應商的 supplier_id 與 contact_email。

5. 郵件撰寫完成後，必須呼叫 `send_email` 工具。
   不得只用文字表示「等待使用者確認」。

6. `send_email` 的人工審查由 Human-in-the-Loop Middleware 處理：
   - approve：使用目前參數執行寄送。
   - edit：使用人工修改後的完整參數執行寄送。
   - reject：取消該次寄送。

7. 在 `send_email` 工具實際回傳成功結果之前，
   不得宣稱郵件已經寄出。

8. 使用繁體中文回覆，內容應清楚、專業且簡潔。
"""


# ## Tools



## 檢查詢價欄位

from typing import Any, TypedDict

from langchain.tools import tool

class ValidateResult(TypedDict):
    is_complete: bool
    missing_fields: list[str]
    errors: list[str]

@tool
def validate_inquiry_data(data: dict[str, Any]) -> ValidateResult:
    """
    檢查詢價資料是否完整，並回傳缺少的欄位與錯誤訊息。

    """
    missing_fields: list[str] = []
    errors: list[str] = []

    # Check item_id
    if not data.get("item_id"):
        missing_fields.append("item_id")

    # Check request_qty, must be a positive integer
    request_qty = data.get("request_qty")
    if request_qty is None:
        missing_fields.append("request_qty")
    elif not isinstance(request_qty, int) or request_qty <= 0:
        errors.append("request_qty 必須是正整數")

    # Check delivery_date, must greater than today
    if not data.get("delivery_date"):
        missing_fields.append("delivery_date")
    else:
        from datetime import datetime

        try:
            delivery_date = datetime.strptime(data["delivery_date"], "%Y-%m-%d").date()
            if delivery_date <= datetime.today().date():
                errors.append("delivery_date 必須大於今天的日期")
        except ValueError:
            errors.append("delivery_date 格式不正確，請使用 YYYY-MM-DD 格式")

    supplier_list = data.get("supplier_list")
    # Check supplier_list, must be a list of dicts with supplier_id and contact_email
    if not supplier_list:
        missing_fields.append("supplier_list")
    else:
        # Check each supplier in the list
        for index, supplier in enumerate(supplier_list):
            if not supplier.get("supplier_id"):
                missing_fields.append(
                    f"supplier_list[{index}].supplier_id"
                )

            if not supplier.get("contact_email"):
                missing_fields.append(
                    f"supplier_list[{index}].contact_email"
                )

    return {
        "is_complete": not missing_fields and not errors,
        "missing_fields": missing_fields,
        "errors": errors,
    }




# ask_user 佔位工具，供 Agent 中斷, 以等待使用者回覆

from typing import Annotated
from langchain.tools import tool

@tool
def ask_user(
        question: Annotated[str, "Agent 要向使用者補問的問題"],
        missing_fields: Annotated[list[str], "缺少的欄位"],
        errors: Annotated[list[str], "錯誤訊息"]
) -> Annotated[str, "使用者的回答"]:
    """要求使用者補充詢價資料。"""
    raise NotImplementedError("This is a placeholder tool for user interaction.")




# Send email tool 

@tool
def send_email(supplier_ids: Annotated[list[str], "供應商編號列表"],
               contact_emails: Annotated[list[str], "供應商聯絡郵件列表"], 
               subject: Annotated[str, "郵件主旨"], 
               body: Annotated[str, "郵件內容"]) -> dict:
    """
    寄送郵件給供應商。

    參數：
    - supplier_ids: 供應商編號列表
    - contact_emails: 供應商聯絡郵件列表
    - subject: 郵件主旨
    - body: 郵件內容

    回傳：
    - 回傳包含 success、status、send_date 與 recipient_count 的字典。
    本 Lab 僅輸出郵件內容，不連線郵件服務。
    """
    # 實際寄送郵件的邏輯應在此實作
    # 這裡僅為範例，實際應使用郵件服務 API 或 SMTP 寄送郵件
    for supplier_id, contact_email in zip(supplier_ids, contact_emails):
        print(f"Sending email to {supplier_id} ({contact_email})")
    print(f"Subject: {subject}")
    print(f"Body:\n{body}")

    # 假設寄送成功
    from datetime import datetime
    return {
        "status": "郵件已寄出",
        "send_date": datetime.now().isoformat(),
        "success": True,
        "recipient_count": len(contact_emails)}


# ## Define the interrupt policy and create the agent



# define the interrupt policy for the Human-in-the-loop

from langchain.agents.middleware import HumanInTheLoopMiddleware, InterruptOnConfig

interrupt_policy = HumanInTheLoopMiddleware(
    interrupt_on={
        "ask_user": InterruptOnConfig(allowed_decisions=["respond"]),
        "send_email": InterruptOnConfig(allowed_decisions=["approve", "edit", "reject"]),
        "validate_inquiry_data": False},
        description_prefix="需要人工介入工具的執行～～"
)



# Create the agent with the system prompt and tools

from langchain.agents import create_agent

# The agent object (variable)
agent = create_agent(
    model="gpt-5-nano",
    system_prompt=system_prompt,
    tools=[validate_inquiry_data, ask_user, send_email],
    # checkpointer=InMemorySaver(),
    middleware=[interrupt_policy])
